import { Component, OnInit } from '@angular/core';
import { AnimationController, NavController, ToastController } from '@ionic/angular';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage {

  usuario = ""
  clave = ""

  constructor(private anim: AnimationController,
    private toast: ToastController,
    private nav: NavController) { }

  validar() {
    if (this.usuario.length > 5) {
      if (this.clave.length > 5 && /\d/.test(this.clave)) {
        if (this.usuario == "ben.gonzalez@duocuc.cl" && this.clave == "Benjita.uwu.69") {
          this.presentToast(/*"Bienvenido " + this.usuario*/"");
this.nav.navigateForward(['/home'])
        } else {
          this.presentToast("Datos incorrectos");
        }
      } else {
        this.animarInput("#clave")
      }
    } else {
      this.animarInput("#usuario")
    }
  }

  animarInput(input: string) {
    let user = document.querySelector(input) as HTMLInputElement
      this.anim.create().addElement(user).duration(200)
      .iterations(3).keyframes([
          { offset: 0, 'transform': 'rotate(-3deg', 'background': '#faacac' },
          { offset: 0.5, 'transform': 'rotate(3deg' },
          { offset: 1, 'transform': 'rotate(0deg', 'background': '##faacac' },
        ]).play()
  }

  async presentToast(texto: string) {
    const toast = await this.toast.create({
      message: texto,
      duration: 1,
      position: 'bottom',
    });
    await toast.present();
  }

}
